import os
import demo

def DirectoryScanner(DirectoryName = "Marvellous"):
    
    ret = os.path.exists(DirectoryName)
    
    if ret == False:
        print("There is no such directory")
        return
    
    ret = os.path.isdir(DirectoryName)
    
    if ret == False:
        print("Unable to scan as it not a directory :")
        return
    
    print("Contents of the directory are  : ")   
 
    for FolderName , SubFolderName , FileName in os.walk(DirectoryName):
        print("Folder  name : ", FolderName)
    
        for subf in SubFolderName:
 
            print("Sub Folder name : ", subf  )
            
        for fname in FileName:
 
            print("File name : ", fname)
    
def main():
    
    DirectoryName = input("Enter the name of directory ")
    DirectoryScanner(DirectoryName)


if __name__ == "__main__":
    main()